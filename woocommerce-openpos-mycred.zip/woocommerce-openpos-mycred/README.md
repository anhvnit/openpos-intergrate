This plugin integrate Openpos work with myCRED plugin

https://wordpress.org/plugins/mycred/

Get Openpos - WooCommerce Point Of Sale(POS) plugin at :

https://codecanyon.net/item/openpos-a-complete-pos-plugins-for-woocomerce/22613341
