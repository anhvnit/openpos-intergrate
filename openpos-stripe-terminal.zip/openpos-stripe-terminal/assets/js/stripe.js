

  (function($) {
    function fetchConnectionToken() {
        console.log(stripe_connection_token_url);
        // Your backend should call /v1/terminal/connection_tokens and return the JSON response from Stripe
        return fetch(stripe_connection_token_url, { method: "POST" })
          .then(response => response.json())
          .then(data => data.secret);
    }
    function unexpectedDisconnect(){
            console.log('Disconnect');
            in_connected = false;
    }

    document.addEventListener("openpos.start.payment", function (e) {
        /*
        if(confirm('Confirm Payment ? zzz'))
        {
          let detail = e['detail'];
          let order = detail['data'];
          let paymentFired = new CustomEvent("openpos.paid.payment", {
            "detail": {"method": detail['method'],"ref": 'test ref', "order_id": order['id'],'message':'Test message',"amount": detail['amount'] }
          });
    
          document.dispatchEvent(paymentFired);
        } */
        var detail = e['detail'];
        var order = detail['data'];
        var terminal = StripeTerminal.create({
            onFetchConnectionToken: fetchConnectionToken,
            onUnexpectedReaderDisconnect: unexpectedDisconnect,
        });
        var method = detail['method'];
        if(method['code'] == 'op_stripe_terminal')
        {
            var paymentIntent = null;  
            //const config = {simulated: true};
            //console.log(stripe_location_id);
    
            $.ajax({
                url: stripe_server_url,
                method: "POST",
                data: {action: 'stripe_get_terminal',order: JSON.stringify(order),payment: JSON.stringify(detail)},
                dataType: 'json',
                success: function(response){
                    
                    in_connected = false;
                    stripe_terminal = null;
                    stripe_terminal_current_intent = null;
                    selectedReader = response;
                    terminal.connectReader(selectedReader).then(function(connectResult) {
                        if (connectResult.error) {
                            var error_msg = connectResult.error;
                            if(connectResult.error['code'])
                            {
                                error_msg =connectResult.error['code'] + ' - ' + connectResult.error['message'];
                            }
                            console.log('Failed to connect: ', connectResult.error);
                            $('body').find('#stripe-charge-btn').addClass('charge-hide-btn');
                            $('body').find('#stripe-message').text('Failed to connect: '+ error_msg);
                            
                        } else {
                            $('body').find('#stripe-charge-btn').removeClass('charge-hide-btn');
                            in_connected = true;
                            stripe_terminal = terminal;
                            $('body').find('#stripe-message').text('Connected to reader: '+connectResult.reader.label);
                            console.log('Connected to reader: ', connectResult.reader.label);
                            $.ajax({
                                url: stripe_server_url,
                                method: "POST",
                                data: {action: 'stripe_create_paymentintent',order: JSON.stringify(order),payment: JSON.stringify(detail)},
                                dataType: 'json',
                                success: function(response){
                                    if(response['status'] == 1)
                                    {
                                       
                                        var client_secret = response['data']['client_secret'];
                                        if(client_secret != undefined && client_secret.length > 0)
                                        {
                                            terminal.collectPaymentMethod(client_secret).then(function(result) {
                                                if (result.error) {
                                                  // Placeholder for handling result.error
                                                  $('body').find('#stripe-message').text('Error: '+result.error);
                                                } else {
                                                  // Placeholder for processing result.paymentIntent
                                                  paymentIntent = result.paymentIntent;
                                                  stripe_terminal_current_intent = result.paymentIntent.id;
                                                  $('body').find('#stripe-message').text('Ready: Please swipe card');
        
                                                  terminal.processPayment(paymentIntent).then(function(result) {
                                                        if (result.error) {
                                                            // Placeholder for handling result.error
                                                            console.log(result.error);
                                                            $('body').find('#stripe-message').text('Error: '+result.error.message);
                                                        } else if (result.paymentIntent) {
                                                        // Placeholder for notifying your backend to capture result.paymentIntent.id
                                                        $('body').find('#stripe-message').text('Processing: Please wait...');
                                                        var payment_intent_id = result.paymentIntent.id;
                                                        $.ajax({
                                                                url: stripe_server_url,
                                                                method: "POST",
                                                                data: {action: 'stripe_capture_paymentintent',payment_intent_id: payment_intent_id},
                                                                dataType: 'json',
                                                                success: function(response){
                                                                    if(response['status'] == 1)
                                                                    {
                                                                        var transaction_id = response['data']['id'];
                                                                        var status = response['data']['status'];
                                                                        
                                                                        if(status == "succeeded" && transaction_id != undefined && transaction_id.length > 0)
                                                                        {
                                                                             $('body').find('#stripe-loading').remove();


                                                                             in_connected = false;
                                                                             stripe_terminal = null;
                                                                             stripe_terminal_current_intent = null;

                                                                            let paymentFired = new CustomEvent("openpos.paid.payment", {
                                                                                "detail": {"method": detail['method'],"ref": transaction_id, "order_id": order['id'],'message':'Transaction: '+transaction_id,"amount": detail['amount'] }
                                                                              });
                                                                        
                                                                              document.dispatchEvent(paymentFired);
                                                                        }
                                                                        console.log(response);
                                                                    }else{
                                                                        $('body').find('#stripe-message').text(response['message']);
                                                                    }
                                                                        
                                                                }
                                                            }); 
                                                        }
                                                    });
        
                                                }
                                              });
                                        }
                                    }else{
                                        $('body').find('#stripe-charge-btn').removeClass('charge-hide-btn');
                                        $('body').find('#stripe-message').text(response['message']);
                                    }
                                        
                                }
                            });
                            
                        }
                    });
    
                }
            });
        }

        

        /*
        const config = {location:stripe_location_id};
        terminal.discoverReaders(config).then(function(discoverResult) {
            if (discoverResult.error) {
                $('body').find('#stripe-charge-btn').addClass('charge-hide-btn');
                console.log('Failed to discover: ', discoverResult.error);
                $('body').find('#stripe-message').text('Failed to discover: '+discoverResult.error);
            } else if (discoverResult.discoveredReaders.length === 0) {
                
                $('body').find('#stripe-charge-btn').addClass('charge-hide-btn');
                $('body').find('#stripe-message').text('No available readers.');
               
            } else {
            // Just select the first reader here.
            var selectedReader = discoverResult.discoveredReaders[0];
              
            
            }
        });
        */
        



        var html_template = '<div id="stripe-loading">';
         html_template += '<div id="stripe-loading-text">';


         html_template += '<p id="stripe-message">Connecting.Please Wait.....</p>';
         html_template += '<p id="stripe-message"><a id="stripe-close-loading-btn" href="javascript:void(0)">Cancel</a><a id="stripe-charge-btn" class="charge-hide-btn" href="javascript:void(0)">Charge</a></p>';


         html_template += '</div>';
         html_template += '</div>';
        $('body').append(html_template);

    });
    $(document).on('click','#stripe-close-loading-btn',function(){
        if(in_connected && stripe_terminal != null)
        {
            $.ajax({
                url: stripe_server_url,
                method: "POST",
                data: {action: 'stripe_cancel_intent_terminal',payment_intent_id: stripe_terminal_current_intent},
                dataType: 'json',
                success: function(response){
                    
                    console.log(response);
                        
                }
            }); 
            stripe_terminal.disconnectReader();
        }
        in_connected = false;
        stripe_terminal = null;
        stripe_terminal_current_intent = null;
        $('body').find('#stripe-loading').remove();
    });

}(jQuery));