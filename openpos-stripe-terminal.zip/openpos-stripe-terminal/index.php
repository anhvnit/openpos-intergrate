<?php
/*
Plugin Name: Woocommerce + openpos + Stripe Terminal
Plugin URI: http://openswatch.com
Description: Stripe Terminal for OpenPOS
Author: anhvnit@gmail.com
Author URI: http://openswatch.com/
Version: 1.0
WC requires at least: 2.6
Text Domain: openpos-stripe-terminal
License: GPL version 2 or later - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
*/


define('OPENPOS_STRIPE_DIR',plugin_dir_path(__FILE__));
define('OPENPOS_STRIPE_URL',plugins_url('openpos-stripe-terminal'));

require(OPENPOS_STRIPE_DIR.'vendor/autoload.php');


if(!function_exists('terminal_stripe_op_addition_payment_methods'))
{
    function terminal_stripe_op_addition_payment_methods($payment_options){


        $payment_options['op_stripe_terminal'] = array(
            'code' => 'op_stripe_terminal',
            'admin_title' => __('Stripe Terminal','openpos'),
            'frontend_title' => __('Stripe Terminal','openpos'),
            'description' => ''
        );

        return $payment_options;
    }
}
add_filter('op_addition_payment_methods','terminal_stripe_op_addition_payment_methods',10,1);


if(!function_exists('terminal_stripe_op_addition_general_setting'))
{
    function terminal_stripe_op_addition_general_setting($addition_general_setting){
        global $OPENPOS_SETTING;
        $allow_payment_methods = $OPENPOS_SETTING->get_option('payment_methods','openpos_payment');
        if(isset($allow_payment_methods['op_stripe_terminal']))
        {
            $addition_general_setting[] =     array(
                'name'    => 'op_stripe_terminal_secret_key',
                'label'   => __( 'Secret Key', 'openpos' ),
                'desc'    => 'Stripe Terminal ',
                'type'    => 'text',
                'default' => ''
            );
            $addition_general_setting[] =     array(
                'name'    => 'op_stripe_terminal_publishable_key',
                'label'   => __( 'Publishable Key', 'openpos' ),
                'desc'    => 'Stripe Terminal ',
                'type'    => 'text',
                'default' => ''
            );
        }
        return $addition_general_setting;
    }
}

add_filter('op_addition_general_setting','terminal_stripe_op_addition_general_setting',10,1);

if(!function_exists('terminal_stripe_op_login_format_payment_data'))
{
    function terminal_stripe_op_login_format_payment_data($payment_method_data,$methods){
        if($payment_method_data['code'] == 'op_stripe_terminal')
        {
            $payment_method_data['type'] = 'terminal';
            $payment_method_data['online_type'] = 'terminal';
        }
        return $payment_method_data;
    }
}

add_filter('op_login_format_payment_data','terminal_stripe_op_login_format_payment_data',20,2);


function op_stripe_connection_token(){
    global $OPENPOS_SETTING;
    $op_stripe_terminal_secret_key = $OPENPOS_SETTING->get_option('op_stripe_terminal_secret_key','openpos_payment');

    \Stripe\Stripe::setApiKey($op_stripe_terminal_secret_key);
    $token = \Stripe\Terminal\ConnectionToken::create();
    echo json_encode($token);
    exit;
}
function op_stripe_create_paymentintent(){
    global $OPENPOS_SETTING;
    $op_stripe_terminal_secret_key = $OPENPOS_SETTING->get_option('op_stripe_terminal_secret_key','openpos_payment');
    $order = isset($_REQUEST['order']) ? json_decode(stripslashes($_REQUEST['order']),true) : array();
    $payment = isset($_REQUEST['payment']) ? json_decode(stripslashes($_REQUEST['payment']),true) : array();
    $amount = isset($payment['amount']) ? $payment['amount'] : 0;
    $result = array(
        'status' => 0 , 
        'message'=> '',
        'data'=> array()
    );
    if($amount > 0)
    {
        try{
            \Stripe\Stripe::setApiKey($op_stripe_terminal_secret_key);
            $currency = get_woocommerce_currency();
            $result_data = \Stripe\PaymentIntent::create([
                "amount" => (int)($amount * 100),
                "currency" => strtolower($currency),
                "payment_method_types" => ["card_present"],
                "capture_method" => "manual",
            ]);
            $result['data'] = $result_data;
            $result['status'] = 1;
        }catch(\Stripe\Error\InvalidRequest $e)
        {
           
            $result['message'] = $e->getMessage();
        }
    }else{
        $result['message'] = "Amount should > 0";
    }
    echo json_encode($result);
    exit;
}
function op_stripe_capture_paymentintent(){
    global $OPENPOS_SETTING;
    $op_stripe_terminal_secret_key = $OPENPOS_SETTING->get_option('op_stripe_terminal_secret_key','openpos_payment');
    $payment_intent_id = isset($_REQUEST['payment_intent_id']) ? $_REQUEST['payment_intent_id'] : '';
    
    $result = array(
        'status' => 0 , 
        'message'=> '',
        'data'=> array()
    );
    if($payment_intent_id)
    {
        try{
            \Stripe\Stripe::setApiKey($op_stripe_terminal_secret_key);
            $intent = \Stripe\PaymentIntent::retrieve($payment_intent_id);
            $result_data = $intent->capture();
            $result['data'] = $result_data;
            $result['status'] = 1;
        }catch(Exception $e)
        {
            $result['message'] = $e->getMessage();
        }
    }else{
        $result['message'] = "Error";
    }
    echo json_encode($result);
    exit;
}
// create connect token
add_action( 'wp_ajax_nopriv_stripe_connection_token', 'op_stripe_connection_token' );
add_action( 'wp_ajax_stripe_connection_token', 'op_stripe_connection_token' );
// create payment intent
add_action( 'wp_ajax_nopriv_stripe_create_paymentintent', 'op_stripe_create_paymentintent' );
add_action( 'wp_ajax_stripe_create_paymentintent', 'op_stripe_create_paymentintent' );
//capture payment
add_action( 'wp_ajax_nopriv_stripe_capture_paymentintent', 'op_stripe_capture_paymentintent' );
add_action( 'wp_ajax_stripe_capture_paymentintent', 'op_stripe_capture_paymentintent' );





add_filter('openpos_pos_header_style','stripe_terminal_pos_header',20,1);
function stripe_terminal_pos_header($handles){
    
    $handles[] = 'openpos.stripe.terminal.styles';
   
    return $handles;
}
add_filter('openpos_pos_footer_js','stripe_terminal_pos_footer',20,1);
function stripe_terminal_pos_footer($handles){
    
    $handles[] = 'openpos.stripe.terminal.base.js';
    $handles[] = 'openpos.stripe.terminal.js';
    return $handles;
}

function terminal_stripe_registerScripts(){
    wp_enqueue_style( 'openpos.stripe.terminal.styles', OPENPOS_STRIPE_URL.'/assets/css/stripe.css');


    wp_enqueue_script('openpos.stripe.terminal.base.js',  'https://js.stripe.com/terminal/v1/');
    wp_add_inline_script('openpos.stripe.terminal.base.js',"
                var stripe_connection_token_url = '".admin_url('admin-ajax.php?action=stripe_connection_token')."';
                var stripe_server_url = '".admin_url('admin-ajax.php')."';
                var stripe_capture_paymentintent_url = '".admin_url('admin-ajax.php?action=stripe_capture_paymentintent')."';
                  
    ");
    wp_enqueue_script('openpos.stripe.terminal.js',  OPENPOS_STRIPE_URL.'/assets/js/stripe.js',array('jquery','openpos.stripe.terminal.base.js'));
}

add_action( 'init', 'terminal_stripe_registerScripts' ,10 );



