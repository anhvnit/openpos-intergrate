<p>Cashier Name : <?php echo $session['name'];?></p>
<p>Login Time : <?php echo $session['logged_time'];?></p>
<p>your app template at here / html / css / js</p>
<p>Dynamic data get from your site</p>