This is bridge plugin make Openpos working with 
WooCommerce Points and Rewards - https://woocommerce.com/products/woocommerce-points-and-rewards/
