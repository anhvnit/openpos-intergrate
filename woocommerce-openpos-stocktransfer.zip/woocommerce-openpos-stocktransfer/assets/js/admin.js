(function($) {
    "use strict";


})( jQuery );