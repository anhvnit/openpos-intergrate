This is plugin add Stock movement manager for openpos plugin

You get get more information about Openpos at 

https://codecanyon.net/item/openpos-a-complete-pos-plugins-for-woocomerce/22613341
